// /*აქ გავაკეთე რეინჯ ინპუთი და იწერება მნიშვნელობები შესაბამის ინფუთში*/
var inp2 = document.querySelector(".inp2")
var inp11 = document.querySelector(".inp12")
var inputLeft = document.getElementById("input-left");
var inputRight = document.getElementById("input-right");
var thumbLeft = document.querySelector(".slider > .thumb.left");
var thumbRight = document.querySelector(".slider > .thumb.right");
var range = document.querySelector(".slider > .range");
var categories = [
    {
        name: "უძრავი ქონება",
        id: 1
    },
    {
        name: "ბიზნესი",
        id: 2
    },
    {
        name: "მედია",
        id: 3
    }
]
var domainList = [
    {
        domainName: "example1",
        domainExtension: ".ge",
        price: 16000,
        categories: [1, 2]
    },
    {
        domainName: "example2",
        domainExtension: ".com.ge",
        price: 25000,
        categories: [2, 3]
    },
    {
        domainName: "example3",
        domainExtension: ".edu.ge",
        price: 5000,
        categories: [2]
    },
    {
        domainName: "example4",
        domainExtension: ".ge",
        price: 3000,
        categories: [3]
    },
    {
        domainName: "example5",
        domainExtension: ".org.ge",
        price: 2000,
        categories: [1, 3]
    }
]
function setLeftValue() {
    var _this = inputLeft,
        min = parseInt(_this.min),
        max = parseInt(_this.max);
    _this.value = Math.min(parseInt(_this.value), parseInt(inputRight.value) - 1);
    var percent = ((_this.value - min) / (max - min)) * 100;
    thumbLeft.style.left = percent + "%";
    range.style.left = percent + "%";
}
setLeftValue();
function setRightValue() {
    var _this = inputRight,
        min = parseInt(_this.min),
        max = parseInt(_this.max);
    _this.value = Math.max(parseInt(_this.value), parseInt(inputLeft.value) + 1);
    var percent = ((_this.value - min) / (max - min)) * 100;
    thumbRight.style.right = (100 - percent) + "%";
    range.style.right = (100 - percent) + "%";
}
setRightValue();
inputLeft.addEventListener("input", function () {
    inp2.value = inputLeft.value
    setLeftValue()
});
inp2.addEventListener("input", function () {
    inputLeft.value = inp2.value
    setLeftValue()
})
inputRight.addEventListener("input", function () {
    inp11.value = inputRight.value
    setRightValue()
});
inp11.addEventListener("input", function () {
    inputRight.value = inp11.value
    setRightValue()
})
//////////////////////////meore
var inp21 = document.querySelector(".inp21")
var inp111 = document.querySelector(".inp111")
var inputLeft1 = document.getElementById("input-left1");
var inputRight1 = document.getElementById("input-right1");
var thumbLeft1 = document.querySelector(".slider1 > .thumb1.left1");
var thumbRight1 = document.querySelector(".slider1 > .thumb1.right1");
var range1 = document.querySelector(".slider1 > .range1");
function setLeftValueV() {
    var _this = inputLeft1,
        min = parseInt(_this.min),
        max = parseInt(_this.max);
    _this.value = Math.min(parseInt(_this.value), parseInt(inputRight1.value) - 1);
    var percent = ((_this.value - min) / (max - min)) * 100;
    thumbLeft1.style.left = percent + "%";
    range1.style.left = percent + "%";
}
setLeftValueV();
function setRightValueV() {
    var _this = inputRight1,
        min = parseInt(_this.min),
        max = parseInt(_this.max);
    _this.value = Math.max(parseInt(_this.value), parseInt(inputLeft1.value) + 1);
    var percent = ((_this.value - min) / (max - min)) * 100;
    thumbRight1.style.right = (100 - percent) + "%";
    range1.style.right = (100 - percent) + "%";
}
setRightValueV();
inputLeft1.addEventListener("input", function () {
    inp21.value = inputLeft1.value
    setLeftValueV()
});
inp21.addEventListener("input", function () {
    inputLeft1.value = inp21.value
    setLeftValueV()
})
inputRight1.addEventListener("input", function () {
    inp111.value = inputRight1.value
    setRightValueV()
});
inp111.addEventListener("input", function () {
    inputRight1.value = inp111.value
    setRightValueV()
})
var rightdom = document.querySelector(".rightdomains")
var maincard = document.querySelector(".maincard")
for (var i of domainList) {
    var tmp = `
<div class="maincard" style="border-radius:0px;">
<div class="nameandphoto">
<img src="icon/dropicon.svg" alt="" class="xc">
<img src="icon/dropiconBord.svg" alt="" class="xc1">
<span class="name">gijashvili${i.domainExtension}</span>
</div>
<div class="sell">
    <div class="spanebi">
        <span>${i.price}</span>
    </div>
    <div class="kalat">
    <span class="sp19">დამატება</span>
    <img src="icon/cart.svg" alt="" class="z">
    </div>
</div>
</div>
<hr>
`
    rightdom.innerHTML += tmp
}
//sort by price
var priceSort = document.querySelector(".pricesort")
priceSort.addEventListener("click", function () {
    domainList.sort((a, b) => {
        return a.price - b.price
    })
    rightdom.innerHTML = ""
    for (var i of domainList) {
        var tmp = `
    <div class="maincard" style="border-radius:0px;>
    <div class="nameandphoto">
    <img src="icon/dropicon.svg" alt="" class="xc">
    <img src="icon/dropiconBord.svg" alt="" class="xc1">
    <span class="name">gijashvili${i.domainExtension}</span>
    <div class="sell">
    <div class="spanebi">
        <span>${i.price}</span>
    </div>
    <div class="kalat">
    <span class="sp19">დამატება</span>
    <img src="icon/cart.svg" alt="" class="z">
    </div>
</div>
    </div>
     
    </div>
    <hr>
    `
        rightdom.innerHTML += tmp
    }
})

var burg = document.querySelector(".burg")
var snav = document.querySelector(".snav")
var cancelphoto = document.querySelector(".cancelphoto")
var category_range = document.querySelector(".category_and_range")
var category_range_mother = document.querySelector(".category_and_range_mother")
var category_child = document.querySelector(".category_child")
var middle = document.querySelector(".middle")
var categories1 = document.querySelector(".categories")
category_range_mother.style.display = "none"
burg.addEventListener("click", function () {
    snav.style.display = "block"
    snav.style.width = "100%"
    snav.style.height = "auto"
    category_range_mother.style.display = "block"
    category_range.style.display = "block"
    category_child.style.display = "block"
    middle.style.display = "block"
    categories1.style.display = "block"
})
cancelphoto.addEventListener("click", function () {
    snav.style.display = "none"

})
// responsivze searchis gaketeba input.valueti daserchva da rangit modzebna
var inp1_search = document.querySelector(".inp1")
var sitkva = document.querySelector("h1")

function resize(word, count) {
    var tmp = ""
    for (var i = 0; i < count; i++) {
        tmp += word[i]
    }
    return tmp
}
function search() {
    sitkva.innerHTML = ""
     
    for (var i of domainList) { 
        if (resize(i.domainName, inp1_search.value.length) == inp1_search.value) {
            var tmp = `  
            <div class="maincard" style="border-radius:0px;>
            <div class="nameandphoto">
            <img src="icon/dropicon.svg" alt="" class="xc">
            <img src="icon/dropiconBord.svg" alt="" class="xc1">
            <span class="name">gijashvili${i.domainExtension}</span>
            <div class="sell">
            <div class="spanebi">
                <span>${i.price}</span>
            </div>
            <div class="kalat">
            <span class="sp19">დამატება</span>
            <img src="icon/cart.svg" alt="" class="z">
            </div>
        </div>
            </div>
             
            </div> 
            <hr>
            `
            snav.style.display = "none"
            rightdom.innerHTML += tmp
             
        }
    }
}

var but_search = document.querySelector(".but_search")
but_search.addEventListener("click", function () {
    // // var fnt = document.querySelectorAll(".fnt")
    // // for (var i of fnt) { 
    // //     i.addEventListener("click", function () {
    // //         // for (var p of categories) {
    // //         //     if (this.value == p.name) {
    // //         //         for (var q of domainList) {
    // //         //             for (var k of q.categories) {
    // //         //                 if (p.id == k) {
    // //         //                     var tmp = `  
    // //         //                     <div class="maincard" style="border-radius:0px;>
    // //         //                     <div class="nameandphoto">
    // //         //                     <img src="icon/dropicon.svg" alt="" class="xc">
    // //         //                     <img src="icon/dropiconBord.svg" alt="" class="xc1">
    // //         //                     <span class="name">gijashvili${q.domainExtension}</span>
    // //         //                     <div class="sell">
    // //         //     <div class="spanebi">
    // //         //         <span>${i.price}</span>
    // //         //     </div>
    // //         //     <div class="kalat">
    // //         //     <span class="sp19">დამატება</span>
    // //         //     <img src="icon/cart.svg" alt="" class="z">
    // //         //     </div>
    // //         // </div>
    // //         //                     </div>
    // //         //                   <hr>
    // //         //                     `
                            
    // //         //                             rightdom.innerHTML += tmp 
    // //         //                 }
    // //         //             }
    // //         //         }
    // //         //     }
    // //         // }
    // //     })
    // }  




    for (var i of domainList) { 
        if (inp2.value < i.price && inp11.value > i.price) {
            var tmp = `  
    <div class="maincard" style="border-radius:0px;>
    <div class="nameandphoto">
    <img src="icon/dropicon.svg" alt="" class="xc">
    <img src="icon/dropiconBord.svg" alt="" class="xc1">
    <span class="name">gijashvili${i.domainExtension}</span>
    <div class="sell">
                <div class="spanebi">
                    <span>${i.price}</span>
                </div>
                <div class="kalat">
                <span class="sp19">დამატება</span>
                <img src="icon/cart.svg" alt="" class="z">
                </div>
            </div>
    </div>
      
    </div> 
    <hr>
    ` 
            rightdom.innerHTML += tmp
            snav.style.display = "none"
        }

    }
    search()
})
var shopcount = document.querySelector(".shopcount")
var kalat = document.querySelectorAll(".kalat")
//  var k=0
for (var i of kalat) {
     
    i.addEventListener("click", function(){
        // k++
        // if(this==kalat[0]){ 
            var counter = 0
        counter++
        console.log(counter)
        if(counter<=1){ 
        shopcount.style.display = "block"
        shopcount.innerHTML = counter
        this.style.width = "120px"
        this.style.height = "36px"
        this.innerHTML = `<img src="icon/agree.svg"> <span style="color:#696974;">კალათაშია</span>`
        this.style.background = "#F5F5F8"
        }
    })
}
/*------------------------------------------კაროჩე აქ ყველა ფუნქციონალი არის სწორად გაკეთებული სორტირება,დასერჩვა დომაინნეიმით,
--------------------------------------------ფასით,ერთი არ გამიკეთებია სიმბოლოებით დასერჩვა
--------------------------------------------კიდე ერთი პრობლემა არი ის რო უაზროდ ემატება ეს მაინქარდის მოდელები ანუ მგონია რო ბათონზე
--------------------------------------------კლიკის გამო ხდება ეგ ზედმეტად ბევრჯერ მიწერია ეგ მოდელები
--------------------------------------------დესკტოპ ვერსიას ძმა ნუ შეხედავ ც4-ია
--------------------------------------------დამატებითი ინფოსთვის დამიკავშირდით ნომერზე 571-52-52-87
*/






// idebit msgavsi sakmianobis daserchva gasascorebelia kide
 
 
// but_search.addEventListener("click", function () {
    var fnt = document.querySelectorAll(".fnt")
    for (var i of fnt) { 
        var c=0
        i.addEventListener("click", function () {
             
            if(this.checked==true){ 
                c++
            console.log(c)
                for (var p of categories) {
                if (this.value == p.name) {
                    for (var q of domainList) {
                        for (var k of q.categories) {
                            if (p.id == k) {
                                var tmp = `  
                                <div class="maincard" style="border-radius:0px;>
                                <div class="nameandphoto">
                                <img src="icon/dropicon.svg" alt="" class="xc">
                                <img src="icon/dropiconBord.svg" alt="" class="xc1">
                                <span class="name">gijashvili${q.domainExtension}</span>
                                <div class="sell">
                                    <div class="spanebi">
                                        <span>${q.price}es aris biznesi</span>
                                    </div>
                                    <div class="kalat">
                                    <span class="sp19">დამატება</span>
                                    <img src="icon/cart.svg" alt="" class="z">
                                    </div>
                                </div>
                                </div> 
                                </div> 
                                <hr>
                                ` 
                                        rightdom.innerHTML += tmp 
                            }
                        }
                    }
                }
            }
        }
        })
    } 
    snav.style.display = "none"
// })
